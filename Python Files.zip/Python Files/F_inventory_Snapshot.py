import pandas as pd
from sqlalchemy import create_engine

engine = create_engine(
    "mssql+pyodbc://localhost\\SQL2025/AdventureWorks2025"
    "?driver=SQL+Server&trusted_connection=yes"
)

query = """
SELECT
    pi.ProductID                                        AS [Product ID],
    CAST(pi.LocationID AS VARCHAR(10)) + '-'
    + ISNULL(LTRIM(RTRIM(pi.Shelf)), 'N/A') + '-'
    + CAST(ISNULL(pi.Bin, 0) AS VARCHAR(10))            AS [Inventory Location Key],
    pi.Quantity                                         AS [Inventory Quantity],
    CONVERT(INT, CONVERT(VARCHAR(8), pi.ModifiedDate, 112))
                                                        AS [Snapshot Date Key]
FROM Production.ProductInventory pi;
"""

df = pd.read_sql(query, engine)
engine.dispose()

print("Shape:")
print(df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn types:")
print(df.dtypes)
print("\nNull counts:")
print(df.isnull().sum())

# Cleaning
df.drop_duplicates(inplace=True)
df["Product ID"] = df["Product ID"].astype(int)
df["Inventory Quantity"] = df["Inventory Quantity"].astype(int)
df["Snapshot Date Key"] = df["Snapshot Date Key"].astype(int)
df["Inventory Location Key"] = df["Inventory Location Key"].str.strip()

# Convert Snapshot Date Key to datetime
df["Snapshot Date"] = pd.to_datetime(
    df["Snapshot Date Key"].astype(str), format="%Y%m%d"
)

df = df[[
    "Product ID",
    "Inventory Location Key",
    "Inventory Quantity",
    "Snapshot Date Key",
    "Snapshot Date"
]]

df.to_csv("Fact_Inventory_Snapshot.csv", index=False, encoding="utf-8-sig")
print("\nFile saved successfully!")