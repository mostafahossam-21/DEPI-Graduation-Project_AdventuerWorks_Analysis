import pandas as pd
from sqlalchemy import create_engine

engine = create_engine(
    "mssql+pyodbc://localhost\\SQL2025/AdventureWorks2025"
    "?driver=SQL+Server&trusted_connection=yes"
)

query = """
SELECT DISTINCT
    CAST(pi.LocationID AS VARCHAR(10)) + '-'
    + ISNULL(LTRIM(RTRIM(pi.Shelf)), 'N/A') + '-'
    + CAST(ISNULL(pi.Bin, 0) AS VARCHAR(10))    AS [Inventory Location Key],
    pi.LocationID                               AS [Location ID],
    LTRIM(RTRIM(pi.Shelf))                      AS [Shelf],
    pi.Bin                                      AS [Bin]
FROM Production.ProductInventory pi;
"""

df = pd.read_sql(query, engine)
engine.dispose()

print("Shape:")
print(df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn types:")
print(df.dtypes)
print("\nNull counts:")
print(df.isnull().sum())

# Cleaning
df.drop_duplicates(inplace=True)
df["Location ID"] = df["Location ID"].astype(int)
df["Bin"] = df["Bin"].astype(int)
df["Shelf"] = df["Shelf"].str.strip()
df["Inventory Location Key"] = df["Inventory Location Key"].str.strip()

df.to_csv("Dim_InventoryLocation.csv", index=False, encoding="utf-8-sig")
print("\nFile saved successfully!")