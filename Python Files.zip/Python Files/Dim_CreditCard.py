import pandas as pd
from sqlalchemy import create_engine

engine = create_engine(
    "mssql+pyodbc://localhost\\SQL2025/AdventureWorks2025"
    "?driver=SQL+Server&trusted_connection=yes"
)

query = """
SELECT
    cc.CreditCardID     AS [Credit Card ID],
    cc.CardType         AS [Card Type]
FROM Sales.CreditCard cc;
"""

df = pd.read_sql(query, engine)
engine.dispose()

print("Shape:")
print(df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn types:")
print(df.dtypes)
print("\nNull counts:")
print(df.isnull().sum())

# Cleaning
df.drop_duplicates(inplace=True)
df["Credit Card ID"] = df["Credit Card ID"].astype(int)
df["Card Type"] = df["Card Type"].str.strip()

df.to_csv("Dim_CreditCard.csv", index=False, encoding="utf-8-sig")
print("\nFile saved successfully!")