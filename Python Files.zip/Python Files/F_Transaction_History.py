import pandas as pd
from sqlalchemy import create_engine

# Connect to SQL Server
engine = create_engine(
    "mssql+pyodbc://localhost\\SQL2025/AdventureWorks2025"
    "?driver=SQL+Server&trusted_connection=yes"
)

# Query
query = """
WITH AllTransactions AS (
    SELECT
        ProductID                AS [Product ID],
        ReferenceOrderID         AS [Reference Order ID],
        ReferenceOrderLineID     AS [Reference Order Line ID],
        TransactionDate          AS [Transaction Date],
        TransactionType          AS [Transaction Type],
        Quantity                 AS [Quantity],
        ActualCost               AS [Actual Cost]
    FROM Production.TransactionHistoryArchive

    UNION ALL

    SELECT
        ProductID                AS [Product ID],
        ReferenceOrderID         AS [Reference Order ID],
        ReferenceOrderLineID     AS [Reference Order Line ID],
        TransactionDate          AS [Transaction Date],
        TransactionType          AS [Transaction Type],
        Quantity                 AS [Quantity],
        ActualCost               AS [Actual Cost]
    FROM Production.TransactionHistory
)
SELECT
    [Product ID],
    CONVERT(INT, CONVERT(VARCHAR(8), [Transaction Date], 112)) AS [Transaction Date Key],
    [Reference Order ID],
    [Reference Order Line ID],
    CASE [Transaction Type]
        WHEN 'W' THEN 'Work Order'
        WHEN 'S' THEN 'Sales Order'
        WHEN 'P' THEN 'Purchase Order'
        ELSE 'Unknown'
    END AS [Transaction Type],
    CASE
        WHEN [Quantity] > 0 THEN 'Stock In'
        WHEN [Quantity] < 0 THEN 'Stock Out'
        ELSE 'Adjustment'
    END AS [Movement Direction],
    ABS([Quantity]) AS [Transaction Quantity],
    [Actual Cost]
FROM AllTransactions;
"""

# Read data
df = pd.read_sql(query, engine)
engine.dispose()

# Explore data
print("Shape:")
print(df.shape)

print("\nFirst 5 rows:")
print(df.head())

print("\nColumn types:")
print(df.dtypes)

print("\nNull counts:")
print(df.isnull().sum())

# Cleaning

# 1. Convert Date Key to datetime
df["Transaction Date"] = pd.to_datetime(
    df["Transaction Date Key"].astype(str), format="%Y%m%d"
)

# 2. Fill nulls in Actual Cost
df["Actual Cost"] = df["Actual Cost"].fillna(0)

# 3. Remove duplicates
df.drop_duplicates(inplace=True)

# 4. Remove zero quantity rows
df = df[df["Transaction Quantity"] != 0]

# 5. Fix data types
df["Product ID"]               = df["Product ID"].astype(int)
df["Reference Order ID"]       = df["Reference Order ID"].astype(int)
df["Reference Order Line ID"]  = df["Reference Order Line ID"].astype(int)
df["Transaction Quantity"]     = df["Transaction Quantity"].astype(int)
df["Actual Cost"]              = df["Actual Cost"].astype(float)

# Reorder columns
df = df[[
    "Product ID",
    "Transaction Date Key",
    "Transaction Date",
    "Reference Order ID",
    "Reference Order Line ID",
    "Transaction Type",
    "Movement Direction",
    "Transaction Quantity",
    "Actual Cost"
]]

# Export to CSV
df.to_csv("FactTransactionHistory.csv", index=False, encoding="utf-8-sig")
print("\nFile saved successfully!")