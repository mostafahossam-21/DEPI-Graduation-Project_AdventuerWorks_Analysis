import pandas as pd
from sqlalchemy import create_engine

engine = create_engine(
    "mssql+pyodbc://localhost\\SQL2025/AdventureWorks2025"
    "?driver=SQL+Server&trusted_connection=yes"
)

query = """
SELECT
    [Status ID],
    [Status Name]
FROM (VALUES
    (1, 'In Process'),
    (2, 'Approved'),
    (3, 'Backordered'),
    (4, 'Rejected'),
    (5, 'Shipped'),
    (6, 'Cancelled')
) AS t([Status ID], [Status Name]);
"""

df = pd.read_sql(query, engine)
engine.dispose()

print("Shape:")
print(df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn types:")
print(df.dtypes)
print("\nNull counts:")
print(df.isnull().sum())

# Cleaning
df.drop_duplicates(inplace=True)
df["Status ID"] = df["Status ID"].astype(int)
df["Status Name"] = df["Status Name"].str.strip()

df.to_csv("Dim_SalesOrderStatus.csv", index=False, encoding="utf-8-sig")
print("\nFile saved successfully!")