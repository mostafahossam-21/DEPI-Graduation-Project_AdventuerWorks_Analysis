USE AdventureWorks2025;
GO

SELECT
    cc.CreditCardID AS [Credit Card ID],
    cc.CardType AS [Card Type]

FROM Sales.CreditCard cc;
GO